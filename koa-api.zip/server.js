const fs = require('fs')
const path = require('path');

const logger = require('koa-logger');
const serve = require('koa-static');
const router = require('koa-router')();
const koaBody = require('koa-body');
const cors = require('@koa/cors');
const Koa = require('koa')
const app = new Koa()

const _ = require('underscore')
app.use(cors());
app.use(logger())
app.use(koaBody())
router.get('/one', one)
    .post('/two', two)
    .get('/three', three)
    .post('/addAai.do', addApi)
    .post('/deletApi.do', deletApi)
    .post('/showApi.do', showApi)
    .post('/itfer-hdqd/rest/activity/addActivity', addActivity)
    .post('/itfer-hdqd/rest/user/saveUserInfo', saveUserInfo)
app.use(router.routes())

// serve files from ./public

app.use(serve(path.join(__dirname, './public')));

async function one(ctx) {
    ctx.body = {name: 'lgn'}
}
async function two(ctx) {
    const body = ctx.request.body
    console.log(body)
    ctx.body = {name: 'ddd'}
}
async function three(ctx) {
    ctx.body = {name: '2222'}
}

let api = require('./api.json')
async function addApi(ctx) {
    const body = ctx.request.body
    
    let isRepetition = _.find(api, (ao) => {
        return ao.id == body.id
    })
    if (isRepetition) {
        ctx.body = {result: 'id重复了'}
    } else {
        api.push(body)
        fs.writeFile('api.json', `${JSON.stringify(api)}`, (err) => {
            if (err) throw err
            console.log('The "data to append" was appended to file!')
        })
        ctx.body = api
    }
}
async function deletApi(ctx) {
    const body = ctx.request.body
    api = api.filter(value => {
        return value.id != body.id
    })
    fs.writeFile('api.json', `${JSON.stringify(api)}`, (err) => {
        if (err) throw err
        console.log('The "data to append" was appended to file!')
    })
    ctx.body = api
}
async function showApi(ctx) {
    api = _.sortBy(api, (ao) => {
        return ao.id
    })
    ctx.body = api
}
async function addActivity(ctx) {
    ctx.body = {
        msg: "添加数据成功",
        status: 0
    }
}
async function saveUserInfo(ctx) {
    ctx.body = {
        "status": 0,
        "result":{
            "power":0  //不是是管理员 那么就是普通学生 进入学生页面
        },
        "msg": "已确认身份信息"
      }
}
app.listen(9080)